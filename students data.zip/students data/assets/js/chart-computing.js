$(function () {

    // =====================================
    // Average hours over year
    // =====================================
            var line = {
              series: [
                { name: "Average:", data: [6, 4, 6, 6, 6, 7, 5, 6, 8, 8, 9, 11] },
                { name: "1st year:", data: [8, 4, 4, 5, 8, 10, 4, 6, 9, 12, 14, 8] },
                { name: "2nd year:", data: [5, 6, 9, 10, 8, 4, 7, 6, 6, 3, 5, 12] },
                { name: "3rd year:", data: [6, 3, 5, 5, 4, 7, 6, 6, 9, 10, 8, 12] },
              ],
              chart: {
              height: 350,
              type: 'line',
              offsetX: -15,
              toolbar: { show: true },
              foreColor: "#adb0bb",
              fontFamily: 'inherit',
              sparkline: { enabled: false },
              zoom: {
                enabled: false
              }
            },
    
            colors: ["#ADB0BB", "#254E7A", "#77A6BA", "#DEC32A"],
    
            dataLabels: {
              enabled: false
            },
            stroke: {
              curve: "smooth",
              width: 2,
            },
    
            grid: {
              borderColor: "rgba(0,0,0,0.1)",
              strokeDashArray: 3,
              xaxis: {
                lines: {
                  show: false,
                },
              },
            },
    
            title: {
              text: 'Average Hours',
              align: 'left'
            },
    
            xaxis: {
              type: 'category',
              categories: ['Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug'],
              labels: {
                style: { cssClass: "grey--text lighten-2--text fill-color" },
              },
            },
    
            };
    
            var chart = new ApexCharts(document.querySelector("#line"), line);
            chart.render();
    
      // =====================================
      // Number of users
      // =====================================
      var donut = {
        color: "#adb5bd",
        series: [1337, 1337, 49],
        labels: ["Undergrade", "Postgrade", "PhD"],
        colors: ["#254E7A", "#77A6BA", "#DEC32A"],
    
        chart: {
          type: "donut",
          fontFamily: "Plus Jakarta Sans', sans-serif",
          foreColor: "#adb0bb",
          toolbar: { show: true },
          width: '100%'
        },
    
        plotOptions: {
          pie: {
            startAngle: 0,
            endAngle: 360,
            donut: {
              labels: {
                show: true,
              
                total: {
                  show: true,
                  showAlways: true,
                  label: 'Total',
                  fontsize: '14px',
                  fontFamily: "Plus Jakarta Sans', sans-serif",
                  fontWeight: 600,
                  color: '#616161',
                  formatter: function (w) {
                    this.fontsize = '24px'
                    this.fontFamily = "Plus Jakarta Sans', sans-serif"
                    this.fontWeight = 600
                    this.color= '#212121'
                    return w.globals.seriesTotals.reduce((a, b) => {
                      return a + b
                    }, 0)}
                },
              },
                size: '75%',
            },
          },
        },
        
        stroke: {
          show: false,
        },
    
        dataLabels: {
          enabled: false,
        },
    
        legend: {
          show: true,
          position: 'bottom',
          horizontalAlign: 'center',
          floating: false,
          fontsize: '10px',
          width: undefined,
          height: undefined,
          
        },
        
        grid: {
          padding: {
            bottom: 0
          }
        },
    
        responsive: [
          {
            breakpoint: 991,
            options: {
            chart: {
            width: 310,
            },
            },
          },
        ],
    
        tooltip: {
          theme: "light",
          fillSeriesColor: false,
        },
      };
    
      var chart = new ApexCharts(document.querySelector("#donut"), donut);
      chart.render();
    
        // =====================================
      // Average hours of each day
      // =====================================
      var bar = {
        series: [
          { name: "Undergraduate students:", data: [4, 6, 12, 8, 10, 5, 3] },
          { name: "Post-graduate students:", data: [5, 8, 10, 8, 4, 4, 4] },
          { name: "PhD students:", data: [5, 4, 7, 6, 6, 3, 5] },
          
        ],
    
        chart: {
          type: "bar",
          height: 345,
          offsetX: -15,
          toolbar: { show: true },
          foreColor: "#adb0bb",
          fontFamily: 'inherit',
          sparkline: { enabled: false },
        },
    
    
        colors: ["#254E7A", "#77A6BA", "#DEC32A"],
    
    
        plotOptions: {
          bar: {
            horizontal: false,
            columnWidth: "35%",
            borderRadius: 2,
            borderRadiusApplication: 'end',
            borderRadiusWhenStacked: 'all'
          },
        },
        markers: { size: 0 },
    
        dataLabels: {
          enabled: false,
        },
    
    
        legend: {
          show: false,
        },
    
    
        grid: {
          borderColor: "rgba(0,0,0,0.1)",
          strokeDashArray: 3,
          xaxis: {
            lines: {
              show: false,
            },
          },
        },
    
        title: {
          text: 'Average Hours',
          align: 'left'
        },
    
        xaxis: {
          type: "category",
          categories: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
          labels: {
            style: { cssClass: "grey--text lighten-2--text fill-color" },
          },
        },
    
        stroke: {
          show: true,
          width: 3,
          lineCap: "butt",
          colors: ["transparent"],
        },
    
    
        tooltip: { theme: "light" },
    
        responsive: [
          {
            breakpoint: 600,
            options: {
              plotOptions: {
                bar: {
                  borderRadius: 3,
                }
              },
            }
          }
        ]
    
    
      };
    
      var chart = new ApexCharts(document.querySelector("#bar"), bar);
      chart.render();
    
    })