$(function () {

    // =====================================
    // Average hours over year - Faculty sci
    // =====================================
            var line = {
              series: [
                { name: "Average:", data: [4, 6, 12, 4, 8, 5, 6, 7, 8, 4, 5, 6] },
                { name: "School of Computing:", data: [5, 8, 10, 8, 4, 4, 4, 5, 8, 2, 3, 3] },
                { name: "School of Engineering:", data: [7, 6, 6, 5, 4, 7, 6, 6, 3, 5, 2, 2] },
                { name: "School of Mathematics, Statistics and Physics:", data: [5, 8, 6, 8, 7, 6, 6, 5, 6, 2, 1, 2,] },
                { name: "School of Natural and Environmental Sciences:", data: [5, 8, 10, 8, 4, 4, 4, 4, 6, 12, 4, 3,] }
              ],
              chart: {
              height: 350,
              type: 'line',
              offsetX: -15,
              toolbar: { show: true },
              foreColor: "#adb0bb",
              fontFamily: 'inherit',
              sparkline: { enabled: false },
              zoom: {
                enabled: false
              }
            },
    
            colors: ["#ADB0BB", "#254E7A", "#77A6BA", "#DEC32A", "#0fb294"],
    
            dataLabels: {
              enabled: false
            },
            stroke: {
              curve: "smooth",
              width: 2,
            },
    
            grid: {
              borderColor: "rgba(0,0,0,0.1)",
              strokeDashArray: 3,
              xaxis: {
                lines: {
                  show: false,
                },
              },
            },
    
            title: {
              text: 'Average Hours',
              align: 'left'
            },
    
            xaxis: {
              type: 'category',
              categories: ['Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug'],
              labels: {
                style: { cssClass: "grey--text lighten-2--text fill-color" },
              },
            },
    
            };
    
            var chart = new ApexCharts(document.querySelector("#line"), line);
            chart.render();
    
    // =====================================
    // Number of users - Faculty sci
    // =====================================
      var donut = {
        color: "#adb5bd",
        series: [299, 490, 215, 333],
        labels: ["School of Computing", "School of Engineering", "School of Mathematics, Statistics and Physics", "School of Natural and Environmental Sciences"],
        colors: ["#254E7A", "#77A6BA", "#DEC32A", "#0fb294"],
    
        chart: {
          type: "donut",
          fontFamily: "Plus Jakarta Sans', sans-serif",
          foreColor: "#adb0bb",
          toolbar: { show: true },
          height: '100%'
        },
    
        plotOptions: {
          pie: {
            startAngle: 0,
            endAngle: 360,
            donut: {
              labels: {
                show: true,
              
                total: {
                  show: true,
                  showAlways: true,
                  label: 'Total',
                  fontsize: '14px',
                  fontFamily: "Plus Jakarta Sans', sans-serif",
                  fontWeight: 600,
                  color: '#616161',
                  formatter: function (w) {
                    this.fontsize = '24px'
                    this.fontFamily = "Plus Jakarta Sans', sans-serif"
                    this.fontWeight = 600
                    this.color= '#212121'
                    return w.globals.seriesTotals.reduce((a, b) => {
                      return a + b
                    }, 0)}
                },
              },
                size: '75%',
            },
          },
        },
        
        stroke: {
          show: false,
        },
    
        dataLabels: {
          enabled: false,
        },
    
        legend: {
          show: true,
          position: 'bottom',
          horizontalAlign: 'left',
          floating: false,
          fontsize: '10px',
          width: undefined,
          height: undefined,
        },
        
        grid: {
          padding: {
            bottom: 24,
          }
        },
    
        responsive: [
          {
            breakpoint: 991,
            options: {
            chart: {
            width: 310,
            },
            },
          },
        ],
    
        tooltip: {
          theme: "light",
          fillSeriesColor: false,
        },
      };
    
      var chart = new ApexCharts(document.querySelector("#donut"), donut);
      chart.render();
    
    // =====================================
    // Average hours of each day - Faculty sci
    // =====================================
      var bar = {
        series: [
          { name: "School of Computing:", data: [4, 6, 12, 8, 10, 5, 3] },
          { name: "School of Engineering:", data: [5, 8, 10, 8, 4, 4, 4] },
          { name: "School of Mathematics, Statistics and Physics:", data: [5, 4, 7, 6, 6, 3, 5] },
          { name: "School of Natural and Environmental Scienses:", data: [2, 4, 5, 5, 3, 4, 2] },
          
        ],
    
        chart: {
          type: "bar",
          height: 345,
          offsetX: -15,
          toolbar: { show: true },
          foreColor: "#adb0bb",
          fontFamily: 'inherit',
          sparkline: { enabled: false },
        },
    
    
        colors: ["#254E7A", "#77A6BA", "#DEC32A", "#0fb294"],
    
    
        plotOptions: {
          bar: {
            horizontal: false,
            columnWidth: "35%",
            borderRadius: 2,
            borderRadiusApplication: 'end',
            borderRadiusWhenStacked: 'all'
          },
        },
        markers: { size: 0 },
    
        dataLabels: {
          enabled: false,
        },
    
    
        legend: {
          show: false,
        },
    
    
        grid: {
          borderColor: "rgba(0,0,0,0.1)",
          strokeDashArray: 3,
          xaxis: {
            lines: {
              show: false,
            },
          },
        },
    
        title: {
          text: 'Average Hours',
          align: 'left'
        },
    
        xaxis: {
          type: "category",
          categories: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
          labels: {
            style: { cssClass: "grey--text lighten-2--text fill-color" },
          },
        },
    
        stroke: {
          show: true,
          width: 3,
          lineCap: "butt",
          colors: ["transparent"],
        },
    
    
        tooltip: { theme: "light" },
    
        responsive: [
          {
            breakpoint: 600,
            options: {
              plotOptions: {
                bar: {
                  borderRadius: 3,
                }
              },
            }
          }
        ]
    
    
      };
    
      var chart = new ApexCharts(document.querySelector("#bar"), bar);
      chart.render();
    
    // =====================================
    // Average hours over year - Faculty Med sci
    // =====================================
    var Medline = {
      series: [
        { name: "Average:", data: [4, 6, 12, 4, 8, 5, 6, 7, 8, 4, 5, 6] },
        { name: "School of School of Biomedical, Nutritional and Sport Sciences:", data: [5, 8, 10, 8, 4, 4, 4, 5, 8, 2, 3, 3] },
        { name: "School of Dental Sciences:", data: [7, 6, 6, 5, 4, 7, 6, 6, 3, 5, 2, 2] },
        { name: "School of Medical Education:", data: [5, 8, 6, 8, 7, 6, 6, 5, 6, 2, 1, 2,] },
        { name: "School of Pharmacy:", data: [4, 4, 4, 5, 8, 10, 8, 4, 6, 12, 4, 3,] },
        { name: "School of Dental Sciences:", data: [6, 5, 4, 3, 5, 2, 2, 7, 6, 7, 6, 6] },
      ],
      chart: {
      height: 350,
      type: 'line',
      offsetX: -15,
      toolbar: { show: true },
      foreColor: "#adb0bb",
      fontFamily: 'inherit',
      sparkline: { enabled: false },
      zoom: {
        enabled: false
      }
    },

    colors: ["#ADB0BB", "#254E7A", "#77A6BA", "#DEC32A", "#0fb294"],

    dataLabels: {
      enabled: false
    },
    stroke: {
      curve: "smooth",
      width: 2,
    },

    grid: {
      borderColor: "rgba(0,0,0,0.1)",
      strokeDashArray: 3,
      xaxis: {
        lines: {
          show: false,
        },
      },
    },

    title: {
      text: 'Average Hours',
      align: 'left'
    },

    xaxis: {
      type: 'category',
      categories: ['Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug'],
      labels: {
        style: { cssClass: "grey--text lighten-2--text fill-color" },
      },
    },

    };

    var chart = new ApexCharts(document.querySelector("#Medline"), Medline);
    chart.render();

    // =====================================
    // Number of users - Faculty Med sci
    // =====================================
    var Meddonut = {
      color: "#adb5bd",
      series: [299, 490, 512, 640, 443],
      labels: ["School of Biomedical, Nutritional and Sport Sciences", "School of Dental Sciences", "School of Medical Education", "School of Pharmacy", "School of Psychology"],
      colors: ["#254E7A", "#77A6BA", "#DEC32A", "#0fb294", "#5A6A85"],
  
      chart: {
        type: "donut",
        fontFamily: "Plus Jakarta Sans', sans-serif",
        foreColor: "#adb0bb",
        toolbar: { show: true },
        height: '100%'
      },
  
      plotOptions: {
        pie: {
          startAngle: 0,
          endAngle: 360,
          donut: {
            labels: {
              show: true,
            
              total: {
                show: true,
                showAlways: true,
                label: 'Total',
                fontsize: '14px',
                fontFamily: "Plus Jakarta Sans', sans-serif",
                fontWeight: 600,
                color: '#616161',
                formatter: function (w) {
                  this.fontsize = '24px'
                  this.fontFamily = "Plus Jakarta Sans', sans-serif"
                  this.fontWeight = 600
                  this.color= '#212121'
                  return w.globals.seriesTotals.reduce((a, b) => {
                    return a + b
                  }, 0)}
              },
            },
              size: '75%',
          },
        },
      },
      
      stroke: {
        show: false,
      },
  
      dataLabels: {
        enabled: false,
      },
  
      legend: {
        show: true,
        position: 'bottom',
        horizontalAlign: 'left',
        floating: false,
        fontsize: '10px',
        width: undefined,
        height: undefined,
      },
      
      grid: {
        padding: {
          bottom: 24,
        }
      },
  
      responsive: [
        {
          breakpoint: 991,
          options: {
          chart: {
          width: 310,
          },
          },
        },
      ],
  
      tooltip: {
        theme: "light",
        fillSeriesColor: false,
      },
    };
  
    var chart = new ApexCharts(document.querySelector("#Meddonut"), Meddonut);
    chart.render();

    // =====================================
    // Average hours of each day - Faculty Med sci
    // =====================================
    var Medbar = {
      series: [
        { name: "Average:", data: [4, 6, 12, 4, 8, 5, 6] },
        { name: "School of School of Biomedical, Nutritional and Sport Sciences:", data: [5, 8, 10, 8, 4, 4, 4] },
        { name: "School of Dental Sciences:", data: [7, 6, 6, 5, 4, 7, 6] },
        { name: "School of Medical Education:", data: [5, 8, 6, 8, 7, 6, 6] },
        { name: "School of Pharmacy:", data: [4, 4, 4, 5, 8, 10, 8] },
        { name: "School of Dental Sciences:", data: [6, 5, 4, 3, 5, 2, 2] },
      ],
  
      chart: {
        type: "bar",
        height: 345,
        offsetX: -15,
        toolbar: { show: true },
        foreColor: "#adb0bb",
        fontFamily: 'inherit',
        sparkline: { enabled: false },
      },
  
  
      colors: ["#254E7A", "#77A6BA", "#DEC32A", "#0fb294"],
  
  
      plotOptions: {
        bar: {
          horizontal: false,
          columnWidth: "35%",
          borderRadius: 2,
          borderRadiusApplication: 'end',
          borderRadiusWhenStacked: 'all'
        },
      },
      markers: { size: 0 },
  
      dataLabels: {
        enabled: false,
      },
  
  
      legend: {
        show: false,
      },
  
  
      grid: {
        borderColor: "rgba(0,0,0,0.1)",
        strokeDashArray: 3,
        xaxis: {
          lines: {
            show: false,
          },
        },
      },
  
      title: {
        text: 'Average Hours',
        align: 'left'
      },
  
      xaxis: {
        type: "category",
        categories: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
        labels: {
          style: { cssClass: "grey--text lighten-2--text fill-color" },
        },
      },
  
      stroke: {
        show: true,
        width: 3,
        lineCap: "butt",
        colors: ["transparent"],
      },
  
  
      tooltip: { theme: "light" },
  
      responsive: [
        {
          breakpoint: 600,
          options: {
            plotOptions: {
              bar: {
                borderRadius: 3,
              }
            },
          }
        }
      ]
  
  
    };
  
    var chart = new ApexCharts(document.querySelector("#Medbar"), Medbar);
    chart.render();

    })